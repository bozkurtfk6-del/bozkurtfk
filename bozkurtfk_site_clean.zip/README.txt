Bozkurt FK - Kayıt formu sadeleştirilmiş sürüm.
Admin sayfasına bağlantı ve açıklamalar kaldırıldı.
